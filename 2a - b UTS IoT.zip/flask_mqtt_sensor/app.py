import json
import threading
import time
import os
from datetime import datetime
import paho.mqtt.client as mqtt
from flask import Flask, render_template
import mysql.connector

app = Flask(__name__)

db_config = {
    'user': 'root',
    'password': '',
    'host': 'localhost',
    'database': 'db_sensor'
}

mqtt_started = False

# -----------------------------
# SIMPAN DATA KE DATABASE
# -----------------------------
def save_to_db(suhu, humidity, lux):
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor()

    timestamp = datetime.now()

    query = """
        INSERT INTO data_sensor (suhu, humidity, lux, timestamp)
        VALUES (%s, %s, %s, %s)
    """

    cursor.execute(query, (suhu, humidity, lux, timestamp))
    conn.commit()

    cursor.close()
    conn.close()

    print(f"[DB] Data disimpan | Suhu={suhu} | Humidity={humidity} | Lux={lux} | {timestamp}")

# -----------------------------
# AMBIL SEMUA DATA
# -----------------------------
def get_all_data():
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor()

    cursor.execute("SELECT id, suhu, humidity, lux, timestamp FROM data_sensor ORDER BY timestamp DESC")
    data = cursor.fetchall()

    cursor.close()
    conn.close()

    return data

# -----------------------------
# MQTT CALLBACK
# -----------------------------
def on_connect(client, userdata, flags, rc):
    print(f"[MQTT] Terhubung ke broker (RC={rc})")
    print("[MQTT] Subscribe topik: sensor/data")
    client.subscribe("sensor/data")

def on_message(client, userdata, msg):
    try:
        data = json.loads(msg.payload.decode())

        suhu = data.get('suhu')
        humidity = data.get('humidity')
        lux = data.get('lux')

        print(f"[MQTT] Pesan diterima: {data}")

        save_to_db(suhu, humidity, lux)

    except Exception as e:
        print(f"[ERROR] Gagal parsing pesan: {e}")

# -----------------------------
# THREAD UNTUK MQTT
# -----------------------------
def run_mqtt():
    print("[THREAD] Menjalankan MQTT client...")
    client = mqtt.Client()

    client.on_connect = on_connect
    client.on_message = on_message

    client.connect("localhost", 1884, 60)
    client.loop_forever()

# -----------------------------
# ROUTE FLASK
# -----------------------------
@app.route('/')
def index():
    data = get_all_data()
    return render_template('index.html', data=data)

# -----------------------------
# MAIN APP
# -----------------------------
if __name__ == '__main__':
    print("[MAIN] Flask dijalankan")

    if not mqtt_started:
        mqtt_started = True

        mqtt_thread = threading.Thread(target=run_mqtt)
        mqtt_thread.daemon = True
        mqtt_thread.start()

        print(f"[MAIN] MQTT thread dimulai | ID: {mqtt_thread.ident}")

    app.run(debug=True, use_reloader=False)
